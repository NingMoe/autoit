Sample VST plugins can be found:

;Karma FX Reverb.dll
http://www.vstplanet.com/Effects/Effects4.htm

;PushTec.dll
http://leftoverlasagne.googlepages.com/