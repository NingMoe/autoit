How to "install" the OutlookEX UDF				2011-05-18
--------------------------------------------------------------------------
This step is mandatory
* Copy OutlookEX.au3 into the %ProgramFiles%\AutoIt3\Include directory

For SciTE integration (user calltips and syntax highlighting)
* Copy au3.user.calltips.api into %ProgramFiles%\AutoIt3\SciTE\api. 
  If the file already exists and contains other definitions then append it to the existing file
* Copy au3.userudfs.properties into %ProgramFiles%\AutoIt3\SciTE\properties
  If the file already exists and contains other definitions then append it to the existing file

Help files and examples
* Copy the *.htm and the remaining *.au3 files to any directory you like. 
  You can't call the help and example scripts from the AutoIt help at the moment


How to use the OutlookEX UDF 		                        2011-05-18
--------------------------------------------------------------------------
* Every script has to have the following format:
  _OL_Open()	                 ; open a onnection to Outlook
  calls to other _OL-functions   ; query or manipulate Outlook items
  _OL_Close()                    ; close the connection to Outlook


General                                                         2011-05-18
--------------------------------------------------------------------------
* <will be added>