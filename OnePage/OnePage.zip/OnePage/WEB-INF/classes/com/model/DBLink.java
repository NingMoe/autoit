package com.model;

public class DBLink {

}
